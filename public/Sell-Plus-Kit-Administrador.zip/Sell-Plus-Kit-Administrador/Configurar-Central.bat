@echo off
title Sell-Plus - Kit del Administrador (SOLO EL DUENO)
color 0B
echo ==================================================
echo    SELL-PLUS - KIT DEL ADMINISTRADOR
echo    USO EXCLUSIVO DEL DUENO DEL SOFTWARE
echo    https://sell-plus-central-f7t1.vercel.app
echo ==================================================
echo.
echo    1) Apuntar este Sell-Plus a la Central
echo    2) Abrir la Central COMPLETA (admin: boton Admin + llave)
echo    3) Ver la direccion guardada ahora mismo
echo    4) Salir
echo.
set /p OP=Escribe el numero y presiona Enter: 
if "%OP%"=="1" goto CONFIGURAR
if "%OP%"=="2" goto ABRIR
if "%OP%"=="3" goto VER
goto FIN

:CONFIGURAR
if not exist "C:\Sell-Plus\resources\app\db\" (
  echo.
  echo  [X] No encontre la carpeta C:\Sell-Plus\resources\app\db
  echo.
  pause
  goto FIN
)
echo https://sell-plus-central-f7t1.vercel.app>"C:\Sell-Plus\resources\app\db\central-url.txt"
echo.
echo  [OK] Listo! Sell-Plus apunta a la Central.
type "C:\Sell-Plus\resources\app\db\central-url.txt"
echo.
pause
goto FIN

:ABRIR
start "" "https://sell-plus-central-f7t1.vercel.app"
echo.
echo  En la pagina, usa el boton Admin (arriba a la derecha)
echo  y escribe tu llave de administrador.
echo.
pause
goto FIN

:VER
echo.
type "C:\Sell-Plus\resources\app\db\central-url.txt" 2>nul
echo.
pause
goto FIN

:FIN
