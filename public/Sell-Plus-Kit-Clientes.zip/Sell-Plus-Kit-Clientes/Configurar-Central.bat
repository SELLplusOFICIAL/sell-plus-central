@echo off
title Sell-Plus - Actualizaciones y Soluciones (Clientes)
color 0A
echo ==================================================
echo    SELL-PLUS - ACTUALIZACIONES Y SOLUCIONES
echo    https://sell-plus-central-f7t1.vercel.app
echo ==================================================
echo.
echo    1) Apuntar Sell-Plus a la Central  (RECOMENDADO)
echo    2) Abrir Actualizaciones y Soluciones
echo    3) Ver la direccion guardada ahora mismo
echo    4) Salir
echo.
set /p OP=Escribe el numero y presiona Enter: 
if "%OP%"=="1" goto CONFIGURAR
if "%OP%"=="2" goto ABRIR
if "%OP%"=="3" goto VER
goto FIN

:CONFIGURAR
if not exist "C:\Sell-Plus\resources\app\db\" (
  echo.
  echo  [X] No encontre la carpeta C:\Sell-Plus\resources\app\db
  echo      Revisa que Sell-Plus este instalado en C:\Sell-Plus
  echo.
  pause
  goto FIN
)
echo https://sell-plus-central-f7t1.vercel.app>"C:\Sell-Plus\resources\app\db\central-url.txt"
echo.
echo  [OK] Listo! Sell-Plus ahora apunta a la Central.
echo  Direccion guardada en central-url.txt:
type "C:\Sell-Plus\resources\app\db\central-url.txt"
echo.
echo  Cierra y abre Sell-Plus, y verifica actualizaciones.
echo.
pause
goto FIN

:ABRIR
start "" "https://sell-plus-central-f7t1.vercel.app/#actualizaciones"
goto FIN

:VER
echo.
echo  Contenido actual de central-url.txt:
type "C:\Sell-Plus\resources\app\db\central-url.txt" 2>nul
echo.
echo  (Si no aparece nada, usa la opcion 1 para configurarla)
echo.
pause
goto FIN

:FIN
